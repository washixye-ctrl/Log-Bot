# WASHI LOG SYSTEM

<p align="center">
  <b>Multi-server Discord Logging Bot</b><br>
  Selective Cross-Server Logs • Automatic Channel Setup • SQLite
</p>

บอท Discord สำหรับบันทึกเหตุการณ์ในเซิร์ฟเวอร์ สร้างหมวดหมู่และห้อง Logs ให้อัตโนมัติ และส่ง Logs ข้ามเซิร์ฟเวอร์ไปยังห้องที่กำหนดได้ โดยแต่ละเซิร์ฟเวอร์ตั้งค่าแยกจากกัน

**Credit: Washi**

## Features

- `/logs setup` สร้างหมวด `LOG SERVER` และ `SYSTEM` พร้อมห้องตามรายการ
- บันทึกสมาชิกเข้า/ออก/ถูกเตะ, ข้อความถูกลบ/แก้ไข, ยศ, ห้อง, Voice, แบน/ปลดแบน, เปลี่ยนชื่อเล่น และ Timeout
- เปลี่ยนห้อง Logs รายประเภทได้
- เปิด/ปิด Logs ต่อเซิร์ฟเวอร์
- Relay ข้ามเซิร์ฟเวอร์แบบเลือก event ได้ เช่น ส่งเฉพาะ `message_delete,member_kick`
- หนึ่งเซิร์ฟเวอร์ส่งไปหลายปลายทางได้
- SQLite เก็บค่าตั้งค่าและ Relay แบบถาวร
- ใช้ได้บน Android Termux, Linux และ VPS

## Requirements

- Node.js 20 ขึ้นไป (แนะนำ Node.js 22/24)
- Discord Bot Application
- บอทต้องอยู่ทั้งเซิร์ฟเวอร์ต้นทางและปลายทางสำหรับ Relay

## Install on Android Termux

```bash
pkg update && pkg upgrade -y
pkg install nodejs-lts git -y
mkdir -p ~/WASHI-LOG-SYSTEM
cd ~/WASHI-LOG-SYSTEM
```

แตก ZIP ลงในโฟลเดอร์นี้ แล้วติดตั้ง:

```bash
npm install
cp .env.example .env
nano .env
```

ใส่ค่าใน `.env`:

```env
DISCORD_TOKEN=ใส่_BOT_TOKEN
CLIENT_ID=ใส่_APPLICATION_ID
GUILD_ID=
```

เริ่มบอท:

```bash
npm start
```

ตรวจ syntax:

```bash
npm run check
```

## Discord Developer Portal

1. เปิด https://discord.com/developers/applications
2. เลือก Application ของบอท
3. ไปที่ **Bot** แล้วเปิด Privileged Gateway Intents:
   - **SERVER MEMBERS INTENT**
   - **MESSAGE CONTENT INTENT**
4. คัดลอก Bot Token ใส่ `DISCORD_TOKEN`
5. คัดลอก Application ID จาก General Information ใส่ `CLIENT_ID`
6. OAuth2 > URL Generator เลือก scopes `bot` และ `applications.commands`

### Bot permissions

ให้สิทธิ์อย่างน้อย:

- View Channels
- Send Messages
- Embed Links
- Read Message History
- Manage Channels (สำหรับ `/logs setup`)
- View Audit Log (ช่วยแยกเหตุการณ์ Kick ออกจาก Leave)

แนะนำให้เชิญด้วย Permission ที่จำเป็นเท่านั้น ไม่จำเป็นต้องให้ Administrator หากตั้ง Permission Overwrite และสิทธิ์ห้องปลายทางถูกต้อง

## First setup

1. เชิญบอทเข้าเซิร์ฟเวอร์ที่ต้องการ
2. รันบอทและรอข้อความ `WASHI LOG SYSTEM online`
3. ในแต่ละเซิร์ฟเวอร์ ใช้ `/logs setup`
4. ห้องจะถูกสร้างในหมวด `LOG SERVER` และ `SYSTEM`
5. ใช้ `/logs status` เพื่อตรวจสอบ

ห้อง Logs ที่สร้างจะซ่อนจาก `@everyone` และอนุญาตให้บอทส่งข้อความได้ ผู้ดูแลที่มี Administrator จะมองเห็นได้ตามสิทธิ์ Discord

## Slash commands

| Command | Description |
|---|---|
| `/logs setup` | สร้างหมวดและห้อง |
| `/logs enable` | เปิด Logs ในเซิร์ฟเวอร์นี้ |
| `/logs disable` | ปิด Logs ในเซิร์ฟเวอร์นี้ |
| `/logs status` | ดูสถานะและจำนวนห้อง |
| `/logs channel-set` | เปลี่ยนห้องของ event หนึ่งประเภท |
| `/logs relay-add` | เพิ่มเส้นทางส่ง Logs ข้ามเซิร์ฟเวอร์ |
| `/logs relay-remove` | ลบ Relay ด้วย ID |
| `/logs relay-list` | ดู Relay ทั้งหมดของเซิร์ฟเวอร์ต้นทาง |
| `/logs relay-test` | ส่งข้อความทดสอบไปทุกปลายทาง |

คำสั่งจัดการต้องมี `Manage Server` หรือ `Administrator`

## Selective cross-server relay

สมมติว่าต้องการส่ง Logs จาก Server A ไปห้อง `#central-logs` ใน Server B:

1. เชิญบอทเข้า Server A และ Server B
2. ใน Server B ตรวจสอบว่าบอทเห็นห้องและมี `View Channel`, `Send Messages`, `Embed Links`
3. ใน Server A ใช้ `/logs relay-add`
4. กรอก `destination-guild-id`, `destination-channel-id`
5. กรอก `events` เป็น `all` หรือ event keys คั่นด้วย comma

ตัวอย่างส่งเฉพาะข้อความถูกลบ, สมาชิกถูกเตะ และการแบน:

```text
message_delete,member_kick,ban_add
```

Event keys ที่รองรับ:

```text
member_join
member_leave
member_kick
message_delete
message_update
role_create
role_delete
role_update
channel_create
channel_delete
channel_update
voice_join
voice_leave
voice_move
ban_add
ban_remove
nickname_update
timeout_update
```

Relay เป็นทิศทางเดียวตามที่เพิ่มไว้ หากต้องการ A → B และ B → A ให้เพิ่ม Relay แยกใน Server B ด้วย บอทจะไม่ส่งต่อข้อความ Logs ของตัวเองซ้ำ เพราะ event handler ข้ามข้อความจากบอท

## Database and backup

ฐานข้อมูลอยู่ที่:

```text
data/washi-logs.sqlite
```

สำรองข้อมูล:

```bash
cp data/washi-logs.sqlite data/washi-logs.backup.sqlite
```

เก็บไฟล์ฐานข้อมูลนี้ไว้เมื่อย้ายเครื่อง เพื่อรักษาการตั้งค่าและ Relay ทั้งหมด

## Important limitations

- Discord ส่ง event ตาม Gateway Intent และข้อมูลที่บอทได้รับเท่านั้น
- ข้อความที่ถูกลบก่อนบอทได้รับ/แคชเนื้อหา อาจไม่มีเนื้อหาให้บันทึก
- การตรวจจับ Kick ใช้ Audit Log และอาจแสดงเป็น Leave หากไม่มีสิทธิ์ View Audit Log หรือ Audit Log ยังไม่พร้อม
- การเปลี่ยน Permission Overwrite ภายในห้อง, การสร้าง Invite, การลบข้อความจำนวนมาก และรายละเอียด Audit Log ขั้นสูง ยังไม่ได้เปิดเป็น event แยกในเวอร์ชันนี้
- ห้องใน `SYSTEM` เป็นห้องโครงสร้างสำหรับต่อยอด ไม่ใช่ระบบ Automod/Wick ทดแทน
- คำสั่ง Global อาจใช้เวลาสักพักกว่าจะปรากฏ หากกำลังทดสอบ ให้ใส่ `GUILD_ID` ใน `.env` เพื่อ register แบบเฉพาะเซิร์ฟเวอร์

## Troubleshooting

**คำสั่ง `/logs` ไม่ขึ้น**
- ตรวจ `CLIENT_ID`, Token และ scope `applications.commands`
- ใส่ `GUILD_ID` ชั่วคราวเพื่อทดสอบเร็วขึ้น
- ปิดและเปิดบอทใหม่

**`/logs setup` สร้างห้องไม่ได้**
- เพิ่ม `Manage Channels`
- ตรวจว่าบอทมีสิทธิ์จัดการหมวดหมู่และห้อง

**Logs ไม่เข้า**
- ใช้ `/logs status`
- ตรวจว่าห้องยังอยู่และบอทมี View Channel / Send Messages / Embed Links
- ตรวจว่าไม่ได้ใช้ `/logs disable`

**Relay ไม่ทำงาน**
- บอทต้องอยู่ในปลายทาง
- ตรวจ Guild ID และ Channel ID
- ตรวจ Permission ในห้องปลายทาง
- ใช้ `/logs relay-test`

---

Made with care by **Washi**.
